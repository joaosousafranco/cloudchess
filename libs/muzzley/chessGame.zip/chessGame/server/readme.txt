//You should change the uuid of the widget for your own widget
	//search for: uuid: 'f8777b06-452e-4fc6-846e-bb74bd459c13',


//You should change the token app for your token app; 
	//search for: var myAppToken = '545b922109226fa2';

